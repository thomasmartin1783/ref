<?php
/**
 * The template for displaying 404 pages (Not Found)
 */

get_header(); 

wp_enqueue_style( '404-page', get_template_directory_uri() . '/css/404-page.css');


?>

    <div class="container-404">

        <div class="left-bar">
            <img class="map-404" src="<?php echo get_template_directory_uri() . '/assets/map.png'?>" alt="">
            <header class="page-header">
                <h1 class="page-title"><?php _e( '404 Not Found', 'theme' ); ?></h1>
            </header>
        </div>
    </div>
        

    <!-- <?php get_search_form(); ?> -->
	


<?php get_footer(); ?>
