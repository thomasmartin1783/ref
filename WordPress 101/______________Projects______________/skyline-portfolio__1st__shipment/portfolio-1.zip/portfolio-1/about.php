<?php 

/* Template Name: About Page */ 

get_header();

wp_enqueue_style( 'about-page', get_template_directory_uri() . '/css/about-page.css');
wp_enqueue_script( 'about', get_template_directory_uri() . '/js/about.js', array(), '1.0.0', true );


?>


<?php if ( have_posts() ) : while ( have_posts() ) : the_post(); ?>



    <div class="row1">
        <div class="textOne">
            Personality
        </div>
        <div class="textTwo">
            Demystified
        </div>
        <!-- <img class="rocket" src="assets/Asset 1.png" alt=""> -->
        <i class="rocket fas fa-space-shuttle fa-lg fa-rotate-270" style="color: #09004b;"></i>
        <img class="smoke" src="<?php echo get_template_directory_uri().'/assets/Asset 3.png'?>" alt="">
    </div>

    <div class="row2">

        <div class="cards" data-aos-duration="1500">
            <div class="card card1" data-aos="fade-down">
                <p class="el1">
                    <?php the_field('about_row_two_text_one');?>
                </p>
                <div class="el2">
                    <i class="fas fa-football-ball"></i>
                </div>
            </div>
            <div class="card card2" data-aos="zoom-in">
                <p class="el1">
                    <?php the_field('about_row_two_text_two');?>   
                </p>
                <div class="el2">
                    <i class="fas fa-drafting-compass"></i> </div>
            </div>
            <div class="card card3" data-aos="fade-up">
                <p class="el1">
                    <?php the_field('about_row_two_text_three');?>
                </p>
                <div class="el2">
                    <i class="fas fa-umbrella-beach"></i>
                </div>
            </div>
        </div>

    </div>


    
    <footer class="ending">
        
        <?php if (get_theme_mod('theme_logo')) : ?>
                
            <a class="logo" href='<?php echo esc_url( home_url( '/' )); ?>' title='<?php echo esc_attr( get_bloginfo( 'name' , 'display' ) ); ?>' rel='home'>
                <img class="logo-image" src='<?php echo esc_url( get_theme_mod( 'theme_logo' ) ); ?>' alt='<?php echo esc_attr( get_bloginfo( 'name' , 'display' ) ); ?>' >
            </a>
        
        <?php else: ?>
            <a class="logo" href='<?php echo esc_url( home_url('/')); ?>' title='<?php echo esc_attr( get_bloginfo( 'name' , 'display' ) ); ?>' rel='home'>
                <span class="logo-text">
                <i class="fab fa-atlassian"></i> 

                <?php echo esc_attr( get_theme_mod( 'text_logo' ) ); ?>
                </span>   
            </a>
        <?php endif; ?>
    
    
        <?php dynamic_sidebar( 'footer_1' ); ?>


        <?php wp_nav_menu( array(
            'menu_class' => 'footer-nav-links',
            'container' => 'ul',
            
        )); ?>
    </footer>
    <div class="copy-right">
        © nibir@ether404.com  2020
    </div>





<?php endwhile; else : ?>
    <p><?php esc_html_e( 'Sorry, no posts matched your criteria.' ); ?></p>
<?php endif; ?>






<?php get_footer();?>