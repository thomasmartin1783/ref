





<script>

    AOS.init({
        duration: 800,
    });

</script>




<?php wp_footer(); ?>

</body>

</html>