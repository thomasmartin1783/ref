<?php 

/* Template Name: Front Page */ 

get_header();
wp_enqueue_style( 'front-page', get_template_directory_uri() . '/css/front-page.css');
wp_enqueue_style( 'contact-form', get_template_directory_uri() . '/css/contact-form.css');


wp_enqueue_script( 'front-page', get_template_directory_uri() . '/js/front-page.js', array(), '1.0.0', true );


?>


<?php if ( have_posts() ) : while ( have_posts() ) : the_post(); ?>


    <div id="container">
        <section id="blue" class="description panel blue">
            <div class="inner">
                <div>
                    <p class="welcome">Welcome To The World of </p>
                    <h1 class="strike-name"><?php the_field('front_section_one')?></h1>
                    <a href="<?php echo get_site_url().'/about'?>"/about">
                        <button class="btttn">
                            Read More
                        </button>
                    </a>

                    <a href="" class="contact" data-aos="fade-up">
                        <button class="btttn-rev">
                            <i class="fas fa-paper-plane"></i> Contact Me
                        </button>
                    </a>
                </div>

                <img class="rocket1" src="<?php echo get_template_directory_uri() . '/assets/rocket.png' ?>" alt="">

                <div class="scroll-down">
                    Scroll down
                    <div class="arrow"></div>
                </div>
            </div>
        </section>

        <section id="#section1" class="panel red">

            <div class="row2">

                <div class="cards" data-aos-duration="1500">
                    <div class="card card1" data-aos="fade-down" style="background: no-repeat center/150% url(<?php the_field('front_section_two_image_one')?>);">
                    
                    </div>
                    <div class="card card2" data-aos="zoom-in"  style="background: no-repeat center/150% url(<?php the_field('front_section_two_image_two')?>);">

                    </div>
                    <div class="card card3" data-aos="fade-up"  style="background: no-repeat center/150% url(<?php the_field('front_section_two_image_three')?>);">

                    </div>
                </div>

            </div>

        </section>


        <section id="#section2" class="panel orange section-book">
            <div class="book">
                <div class="book__form">
                    <form role="form" class="contact-form" method="POST">
                        <h2 class="contact-heading">
                            Contact now
                        </h2>
                        <div class="form-control">
                            <input type="text" name="contact-name" class="form__input" placeholder="Full name" id="name"
                                required />
                            <label for="name" class="form__label">Full name</label>
                        </div>

                        <div class="form-control">
                            <input type="email" name="contact-email" class="form__input" placeholder="Email address" id="email"
                                required />
                            <label for="email" class="form__label">Email address</label>
                        </div>

                        <div class="form-control">
                            <input type="subject" class="form__input" placeholder="Subject" name="contact-subject" id="subject">
                            <label for="subject" class="form__label">Subject</label>
                        </div>
                        <div class="form-control">
                            <textarea name="contact-details" class="form__input" id="details" placeholder="Details"></textarea>
                            <label for="details" class="form__label">Details</label>
                        </div>
                        <button name="submitbttn" class="contact-btn" type="submit">Next step &rarr;</button>
                    </form>
                </div>
            </div>

        </section>




        <section id="#section3" class="panel purple">
            <footer class="ending">
            
            <?php if (get_theme_mod('theme_logo')) : ?>
                    
                <a class="logo" href='<?php echo esc_url( home_url( '/' )); ?>' title='<?php echo esc_attr( get_bloginfo( 'name' , 'display' ) ); ?>' rel='home'>
                    <img class="logo-image" src='<?php echo esc_url( get_theme_mod( 'theme_logo' ) ); ?>' alt='<?php echo esc_attr( get_bloginfo( 'name' , 'display' ) ); ?>' >
                </a>
            
            <?php else: ?>
                <a class="logo" href='<?php echo esc_url( home_url('/')); ?>' title='<?php echo esc_attr( get_bloginfo( 'name' , 'display' ) ); ?>' rel='home'>
                    <span class="logo-text">
                    <i class="fab fa-atlassian"></i> 

                    <?php echo esc_attr( get_theme_mod( 'text_logo' ) ); ?>
                    </span>   
                </a>
            <?php endif; ?>
        
        
            <?php dynamic_sidebar( 'footer_1' ); ?>


            <?php wp_nav_menu( array(
                'menu_class' => 'footer-nav-links',
                'container' => 'ul',
                
            )); ?>
        </footer>
        <div class="copy-right">
            © nibir@ether404.com  2020
        </div>

    </section>
        <!-- <section id="#section4" class="panel green">
            FOUR
        </section> -->
        <!-- <section id="#section5" class="panel blue">
            FIVE
        </section> -->

    </div>

    <div class="section_nav">
        <a class="active" href="#description">- 00</a>
        <a href="#section1">- 01</a>
        <a href="#section2">- 02</a>
        <a href="#section3">- 03</a>
        <!-- <a href="#section4">- 04</a> -->
        <!-- <a href="#section5">- 05</a> -->
    </div>



<?php endwhile; else : ?>
    <p><?php esc_html_e( 'Sorry, no posts matched your criteria.' ); ?></p>
<?php endif; ?>




<?php get_footer();?>