<?php

/**
 * Proper way to enqueue scripts and styles
 */
function theme_scripts() {
    wp_enqueue_style( 'style-name', get_stylesheet_uri() );
    
    wp_enqueue_style( 'navbar', get_template_directory_uri() . '/css/navbar.css');

    wp_enqueue_style( 'font-face', get_template_directory_uri() . '/css/font-face.css');
    wp_enqueue_style( 'footer', get_template_directory_uri() . '/css/footer.css');
    
    
    
    wp_enqueue_style( 'aos', get_template_directory_uri() . '/associations/aos/dist/aos.css');
    wp_enqueue_style( 'hamburgers', get_template_directory_uri() . '/associations/hamburgers/hamburgers.css');
    


    wp_enqueue_style( 'font-awesome', 'https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.14.0/css/all.min.css');
    



    // wp_enqueue_script( 'script-name', get_template_directory_uri() . '/js/example.js', array(), '1.0.0', true );
    // true footer
    // false header
    wp_enqueue_script( 'navbar', get_template_directory_uri() . '/js/navbar.js', array(), '1.0.0', true );
    
    wp_enqueue_script( 'aos', get_template_directory_uri() . '/associations/aos/dist/aos.js', true );
    



    wp_register_script( 'gsap-min', 'https://cdnjs.cloudflare.com/ajax/libs/gsap/3.5.1/gsap.min.js', true );
    wp_enqueue_script('gsap-min');
    
    wp_register_script( 'scrollTrigger','https://s3-us-west-2.amazonaws.com/s.cdpn.io/16327/ScrollTrigger.min.js', true );
    wp_enqueue_script('scrollTrigger');
    
    wp_register_script( 'scrollToPlugin','https://cdnjs.cloudflare.com/ajax/libs/gsap/3.3.3/ScrollToPlugin.min.js', true );
    wp_enqueue_script('scrollToPlugin');



}
add_action( 'wp_enqueue_scripts', 'theme_scripts' );



@ini_set('upload_max_size' , '64M');
@ini_set('post_max_size' , '64M');
@ini_set('max_execution_time' , '300');




/**
 * Proper way to add Logo Upload Capability
 */

function theme_customizer( $wp_customize ) {

    $wp_customize->add_section( 'theme_logo_section' , array(
        'title' => __( 'Logo' , 'theme'),
        'priority' => 30,
        'description' => 'Upload a Logo to replace the default site name and description in the header',

    ));

    $wp_customize->add_setting( 'theme_logo' );

    $wp_customize->add_control( new WP_Customize_Image_Control( $wp_customize, 'theme_logo' , array(
        'label' => __( 'Logo' , 'theme' ),
        'section' => 'theme_logo_section',
        'settings' => 'theme_logo',
    )));

    $wp_customize->add_setting( 'text_logo' );


    $wp_customize->add_control( new WP_Customize_Control( $wp_customize, 'text_logo' , array(
        'label' => __( 'Logo Text' , 'text' ),
        'section' => 'theme_logo_section',
        'settings' => 'text_logo',
    )));
}

add_action('customize_register' , 'theme_customizer');


/**

     Add Menu support to WordPress
     sidebar menu option

*/
function register_my_menu() {
    register_nav_menu('header-menu',__( 'Header Menu' ));
}
add_action( 'init', 'register_my_menu' );




/**
 * Register our sidebars and widgetized areas.
 *
 */
function theme_widgets_init() {

    register_sidebar( array(
        'name'          => 'Footer 1',
        'id'            => 'footer_1',
    ) );
    register_sidebar( array(
        'name'          => 'Sidebar Page',
        'id'            => 'sidebar_1',
    ) );
    register_sidebar( array(
        'name'          => 'Sidebar Blog Page',
        'id'            => 'sidebar_2',
    ) );

}
add_action( 'widgets_init', 'theme_widgets_init' );




/**
 * 
 *  Replaces the excerpt "Read More" text by a link
 *
 */
function new_excerpt_more($more) {
    global $post;
 return '<a class="moretag" href="'. get_permalink($post->ID) . '"> Read More...</a>';
}
add_filter('excerpt_more', 'new_excerpt_more');








require_once get_template_directory() . '/includes/required-plugins.php';








global $wpdb;
$charset_collate = $wpdb->get_charset_collate();

$sql = "CREATE TABLE `{$wpdb->base_prefix}contacts` (
    `id` int(11) AUTO_INCREMENT,
    `name` varchar(100) NOT NULL,
	`email` varchar(100) NOT NULL,
	`subject` varchar(100),
	`details` text,
    PRIMARY KEY(id) 
) $charset_collate;";

require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
dbDelta($sql);



if( !empty($_POST['contact-name']) && !empty($_POST['contact-email']) ) {

    // print_r($_POST);

    $data = array(
        'name' => $_POST['contact-name'],
        'email' => $_POST['contact-email'],
        'subject' => $_POST['contact-subject'],
        'details' => $_POST['contact-details'],
    );

    $table_name = "{$wpdb->base_prefix}contacts";

    $result = $wpdb->insert($table_name,$data,$format=NULL);

    if($result==1) {
        echo "<h1>Contact Saved</h1>";
    }else {
        echo "<h1>Unable to Save</h1>";		
    }
}










function remove_admin_bar() {
    if(!current_user_can('administrator') && !is_admin()) {
        show_admin_bar(false);
    }
}

add_action('after_setup_theme', 'remove_admin_bar');





/**
 * WordPress function for redirecting users on login based on user role
 */
function my_login_redirect( $url, $request, $user ){
    if( $user && is_object( $user ) && is_a( $user, 'WP_User' ) ) {
        if( $user->has_cap( 'administrator' ) ) {
            $url = admin_url();
        } else {
            $url = home_url();
        }
    }
    return $url;
}
add_filter('login_redirect', 'my_login_redirect', 10, 3 );
















if( function_exists('acf_add_local_field_group') ):

acf_add_local_field_group(array(
	'key' => 'group_5f612b30d66b3',
	'title' => 'AboutPage',
	'fields' => array(
		array(
			'key' => 'field_5f612b51ee4f4',
			'label' => 'About Row Two Text One',
			'name' => 'about_row_two_text_one',
			'type' => 'text',
			'instructions' => '',
			'required' => 1,
			'conditional_logic' => 0,
			'wrapper' => array(
				'width' => '',
				'class' => '',
				'id' => '',
			),
			'default_value' => 'Lorem ipsum dolor sit, amet consectetur adipisicing elit. Dolores, exercitationem.',
			'placeholder' => 'Write About Your Hobbies',
			'prepend' => '',
			'append' => '',
			'maxlength' => 160,
		),
		array(
			'key' => 'field_5f612c29ee4f6',
			'label' => 'About Row Two Text Two',
			'name' => 'about_row_two_text_two',
			'type' => 'text',
			'instructions' => '',
			'required' => 1,
			'conditional_logic' => 0,
			'wrapper' => array(
				'width' => '',
				'class' => '',
				'id' => '',
			),
			'default_value' => 'Lorem ipsum dolor sit, amet consectetur adipisicing elit. Dolores, exercitationem.',
			'placeholder' => 'Write About Your Works Or Things You Like To Create',
			'prepend' => '',
			'append' => '',
			'maxlength' => 160,
		),
		array(
			'key' => 'field_5f612c56ee4f7',
			'label' => 'About Row Two Text Three',
			'name' => 'about_row_two_text_three',
			'type' => 'text',
			'instructions' => '',
			'required' => 1,
			'conditional_logic' => 0,
			'wrapper' => array(
				'width' => '',
				'class' => '',
				'id' => '',
			),
			'default_value' => 'Lorem ipsum dolor sit, amet consectetur adipisicing elit. Dolores, exercitationem.',
			'placeholder' => 'Write About Your Adventures Where You Have Been',
			'prepend' => '',
			'append' => '',
			'maxlength' => 160,
		),
	),
	'location' => array(
		array(
			array(
				'param' => 'page_template',
				'operator' => '==',
				'value' => 'about.php',
			),
		),
	),
	'menu_order' => 0,
	'position' => 'acf_after_title',
	'style' => 'default',
	'label_placement' => 'top',
	'instruction_placement' => 'label',
	'hide_on_screen' => array(
		0 => 'the_content',
		1 => 'excerpt',
		2 => 'discussion',
		3 => 'revisions',
		4 => 'slug',
		5 => 'format',
		6 => 'featured_image',
		7 => 'send-trackbacks',
	),
	'active' => true,
	'description' => '',
));

acf_add_local_field_group(array(
	'key' => 'group_5f627e18b093c',
	'title' => 'BlogPosts',
	'fields' => array(
	),
	'location' => array(
		array(
			array(
				'param' => 'page_template',
				'operator' => '==',
				'value' => 'home.php',
			),
		),
	),
	'menu_order' => 0,
	'position' => 'acf_after_title',
	'style' => 'default',
	'label_placement' => 'top',
	'instruction_placement' => 'label',
	'hide_on_screen' => array(
		0 => 'the_content',
		1 => 'excerpt',
		2 => 'slug',
		3 => 'format',
		4 => 'featured_image',
		5 => 'send-trackbacks',
	),
	'active' => true,
	'description' => '',
));

acf_add_local_field_group(array(
	'key' => 'group_5f610592b84b8',
	'title' => 'FrontPage',
	'fields' => array(
		array(
			'key' => 'field_5f6105cc4bfff',
			'label' => 'Front Section One',
			'name' => 'front_section_one',
			'type' => 'text',
			'instructions' => 'Your Name',
			'required' => 1,
			'conditional_logic' => 0,
			'wrapper' => array(
				'width' => '',
				'class' => '',
				'id' => '',
			),
			'default_value' => 'John Doe',
			'placeholder' => 'John Doe',
			'prepend' => '',
			'append' => '',
			'maxlength' => 25,
		),
		array(
			'key' => 'field_5f61063c4c000',
			'label' => 'Front Section Two Tab 1',
			'name' => '',
			'type' => 'tab',
			'instructions' => '',
			'required' => 0,
			'conditional_logic' => 0,
			'wrapper' => array(
				'width' => '',
				'class' => '',
				'id' => '',
			),
			'placement' => 'top',
			'endpoint' => 0,
		),
		array(
			'key' => 'field_5f61086e7bb4a',
			'label' => 'Front Section Two Image One',
			'name' => 'front_section_two_image_one',
			'type' => 'image',
			'instructions' => '',
			'required' => 1,
			'conditional_logic' => 0,
			'wrapper' => array(
				'width' => '',
				'class' => '',
				'id' => '',
			),
			'return_format' => 'url',
			'preview_size' => 'thumbnail',
			'library' => 'all',
			'min_width' => '',
			'min_height' => '',
			'min_size' => '',
			'max_width' => '',
			'max_height' => '',
			'max_size' => '',
			'mime_types' => '',
		),
		array(
			'key' => 'field_5f610cb782f66',
			'label' => 'Front Section Two Image Two',
			'name' => 'front_section_two_image_two',
			'type' => 'image',
			'instructions' => '',
			'required' => 1,
			'conditional_logic' => 0,
			'wrapper' => array(
				'width' => '',
				'class' => '',
				'id' => '',
			),
			'return_format' => 'url',
			'preview_size' => 'thumbnail',
			'library' => 'all',
			'min_width' => '',
			'min_height' => '',
			'min_size' => '',
			'max_width' => '',
			'max_height' => '',
			'max_size' => '',
			'mime_types' => '',
		),
		array(
			'key' => 'field_5f610cd382f67',
			'label' => 'Front Section Two Image Three',
			'name' => 'front_section_two_image_three',
			'type' => 'image',
			'instructions' => '',
			'required' => 1,
			'conditional_logic' => 0,
			'wrapper' => array(
				'width' => '',
				'class' => '',
				'id' => '',
			),
			'return_format' => 'url',
			'preview_size' => 'thumbnail',
			'library' => 'all',
			'min_width' => '',
			'min_height' => '',
			'min_size' => '',
			'max_width' => '',
			'max_height' => '',
			'max_size' => '',
			'mime_types' => '',
		),
	),
	'location' => array(
		array(
			array(
				'param' => 'page_template',
				'operator' => '==',
				'value' => 'front-page.php',
			),
		),
	),
	'menu_order' => 0,
	'position' => 'acf_after_title',
	'style' => 'default',
	'label_placement' => 'top',
	'instruction_placement' => 'label',
	'hide_on_screen' => array(
		0 => 'the_content',
		1 => 'excerpt',
		2 => 'discussion',
		3 => 'slug',
		4 => 'format',
		5 => 'featured_image',
		6 => 'send-trackbacks',
	),
	'active' => true,
	'description' => '',
));

acf_add_local_field_group(array(
	'key' => 'group_5f622c577625e',
	'title' => 'PagePage',
	'fields' => array(
		array(
			'key' => 'field_5f622c5eea3ed',
			'label' => 'Page Title Image',
			'name' => 'page_title_image',
			'type' => 'image',
			'instructions' => 'Please Upload 1920 x 1080 size FullHD image for best result !!!',
			'required' => 1,
			'conditional_logic' => 0,
			'wrapper' => array(
				'width' => '',
				'class' => '',
				'id' => '',
			),
			'return_format' => 'url',
			'preview_size' => 'thumbnail',
			'library' => 'all',
			'min_width' => '',
			'min_height' => '',
			'min_size' => '',
			'max_width' => '',
			'max_height' => '',
			'max_size' => '',
			'mime_types' => '',
		),
		array(
			'key' => 'field_5f622d037b9a2',
			'label' => 'Page Content Image',
			'name' => 'page_content_image',
			'type' => 'image',
			'instructions' => '',
			'required' => 0,
			'conditional_logic' => 0,
			'wrapper' => array(
				'width' => '',
				'class' => '',
				'id' => '',
			),
			'return_format' => 'url',
			'preview_size' => 'thumbnail',
			'library' => 'all',
			'min_width' => '',
			'min_height' => '',
			'min_size' => '',
			'max_width' => '',
			'max_height' => '',
			'max_size' => '',
			'mime_types' => '',
		),
	),
	'location' => array(
		array(
			array(
				'param' => 'page_template',
				'operator' => '==',
				'value' => 'page.php',
			),
		),
	),
	'menu_order' => 0,
	'position' => 'acf_after_title',
	'style' => 'default',
	'label_placement' => 'top',
	'instruction_placement' => 'label',
	'hide_on_screen' => '',
	'active' => true,
	'description' => '',
));

acf_add_local_field_group(array(
	'key' => 'group_5f6252382b6a5',
	'title' => 'Post',
	'fields' => array(
		array(
			'key' => 'field_5f625240acc9a',
			'label' => 'Post Image',
			'name' => 'post_image',
			'type' => 'image',
			'instructions' => '',
			'required' => 0,
			'conditional_logic' => 0,
			'wrapper' => array(
				'width' => '',
				'class' => '',
				'id' => '',
			),
			'return_format' => 'url',
			'preview_size' => 'thumbnail',
			'library' => 'all',
			'min_width' => '',
			'min_height' => '',
			'min_size' => '',
			'max_width' => '',
			'max_height' => '',
			'max_size' => '',
			'mime_types' => '',
		),
		array(
			'key' => 'field_5f6252dea37bd',
			'label' => 'Post Date',
			'name' => 'post_date',
			'type' => 'date_picker',
			'instructions' => '',
			'required' => 0,
			'conditional_logic' => 0,
			'wrapper' => array(
				'width' => '',
				'class' => '',
				'id' => '',
			),
			'display_format' => 'd/m/Y',
			'return_format' => 'd/m/Y',
			'first_day' => 1,
		),
	),
	'location' => array(
		array(
			array(
				'param' => 'post_type',
				'operator' => '==',
				'value' => 'post',
			),
		),
	),
	'menu_order' => 0,
	'position' => 'acf_after_title',
	'style' => 'default',
	'label_placement' => 'top',
	'instruction_placement' => 'label',
	'hide_on_screen' => '',
	'active' => true,
	'description' => '',
));

acf_add_local_field_group(array(
	'key' => 'group_5f6256f548767',
	'title' => 'View Contacts',
	'fields' => array(
	),
	'location' => array(
		array(
			array(
				'param' => 'page_template',
				'operator' => '==',
				'value' => 'view-contacts-page.php',
			),
		),
	),
	'menu_order' => 0,
	'position' => 'acf_after_title',
	'style' => 'default',
	'label_placement' => 'top',
	'instruction_placement' => 'label',
	'hide_on_screen' => array(
		0 => 'the_content',
		1 => 'excerpt',
		2 => 'discussion',
		3 => 'comments',
		4 => 'slug',
		5 => 'format',
		6 => 'featured_image',
		7 => 'categories',
		8 => 'tags',
		9 => 'send-trackbacks',
	),
	'active' => true,
	'description' => '',
));

endif;