<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Home | Portfolio</title>


    <link rel="icon" href="<?php echo get_template_directory_uri() . '/assets/favicon.ico'?>">
    
    
    <?php wp_head(); ?>
</head>

<body>

   
    <nav class="navigation" data-aos="fade-down">
        <!-- Logo Upload -->
        <?php if (get_theme_mod('theme_logo')) : ?>
                
            <a class="logo" href='<?php echo esc_url( home_url( '/' )); ?>' title='<?php echo esc_attr( get_bloginfo( 'name' , 'display' ) ); ?>' rel='home'>
                <img class="logo-image" src='<?php echo esc_url( get_theme_mod( 'theme_logo' ) ); ?>' alt='<?php echo esc_attr( get_bloginfo( 'name' , 'display' ) ); ?>' >
            </a>
    
        <?php else: ?>
            <a class="logo" href='<?php echo esc_url( home_url('/')); ?>' title='<?php echo esc_attr( get_bloginfo( 'name' , 'display' ) ); ?>' rel='home'>
                <span class="logo-text">
                <i class="fab fa-atlassian"></i> 

                <?php echo esc_attr( get_theme_mod( 'text_logo' ) ); ?>
                </span>   
            </a>
        <?php endif; ?>


        <div class="hamburger hamburger--vortex" type="button">
            <span class="hamburger-box">
                <span class="hamburger-inner"></span>
            </span>
        </div>

        <?php wp_nav_menu( array(
            'menu_class' => 'nav-links1',
            'container' => 'ul',
        )); ?>
   
    </nav>


  