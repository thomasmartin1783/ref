<?php 

/* Template Name: Blog Page */ 

get_header();
wp_enqueue_style( 'blog-homepage', get_template_directory_uri() . '/css/blog-homepage.css');

?>

<div class="page-container">

    <div class="page-title-img" style="background: no-repeat center/130% url(<?php echo get_template_directory_uri().'/assets/mountains.jpg'?>);">
    </div>
    
    <div class="page-wrapper">

    <aside class="page-sidebar">
        <?php dynamic_sidebar( 'sidebar_2' ); ?>
    </aside>

   
<?php if ( have_posts() ) : while ( have_posts() ) : the_post(); ?>

        <div class="page-inner">
            <h1 class="page-title">
                <a href="<?php the_permalink(); ?>">
                <?php the_title();?>
                </a>
            </h1>

            <p class="page-date"><?php the_time('F, j, Y'); ?></p>

            <img class="page-content-image" src="<?php the_field('post_image');?>" alt="">


            <p class="single-post-author"><?php the_author(); ?></p>
            <p><?php the_category(); ?></p>


            <p class="page-content"><?php the_excerpt();?></p>
        </div>
        

<?php endwhile; else : ?>
    <div class="container">
        <p><?php esc_html_e( 'Sorry, no posts matched your criteria.' ); ?></p>
    </div>
<?php endif; ?>




</div>



        <footer class="ending">
            
            <?php if (get_theme_mod('theme_logo')) : ?>
                    
                <a class="logo" href='<?php echo esc_url( home_url( '/' )); ?>' title='<?php echo esc_attr( get_bloginfo( 'name' , 'display' ) ); ?>' rel='home'>
                    <img class="logo-image" src='<?php echo esc_url( get_theme_mod( 'theme_logo' ) ); ?>' alt='<?php echo esc_attr( get_bloginfo( 'name' , 'display' ) ); ?>' >
                </a>
            
            <?php else: ?>
                <a class="logo" href='<?php echo esc_url( home_url('/')); ?>' title='<?php echo esc_attr( get_bloginfo( 'name' , 'display' ) ); ?>' rel='home'>
                    <span class="logo-text">
                    <i class="fab fa-atlassian"></i> 

                    <?php echo esc_attr( get_theme_mod( 'text_logo' ) ); ?>
                    </span>   
                </a>
            <?php endif; ?>
        
        
            <?php dynamic_sidebar( 'footer_1' ); ?>


            <?php wp_nav_menu( array(
                'menu_class' => 'footer-nav-links',
                'container' => 'ul',
                
            )); ?>
        </footer>
        <div class="copy-right">
            © nibir@ether404.com  2020
        </div>



</div>







    <style>

        .post-categories {
            list-style: none;
            color: #4488ff;
            padding: .2rem 0;
            margin-bottom: 1rem;
            border-bottom: 3px solid #0e0739;
            display: inline-block;
        }

        .moretag {
            color: #4488ff;
        }
        

    </style>




<?php get_footer();?>