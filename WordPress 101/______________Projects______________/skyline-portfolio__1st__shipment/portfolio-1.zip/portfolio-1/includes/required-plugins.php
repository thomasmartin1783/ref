<?php




require_once get_template_directory() . '/includes/class-tgm-plugin-activation.php';

add_action( 'tgmpa_register', 'Theme101_register_required_plugins' );





function Theme101_register_required_plugins() {
	

	$plugins = array(

		// This is an example of how to include a plugin bundled with a theme.
		array(
			'name'               => 'Advanced Custom Fields Plugin',
			'slug'               => 'advanced-cusotm-theme-plugin',
			'source'             => get_template_directory() . '/includes/plugins/advanced-custom-fields.5.9.1.zip',
			'required'           => true, 
			'version'            => '5.9.1', 


			'force_activation'   => true, // If true, plugin is activated upon theme activation and cannot be deactivated until theme switch.
			'force_deactivation' => false, // If true, plugin is deactivated upon theme switch, useful for theme-specific plugins.
			'external_url'       => '', // If set, overrides default API URL and points to an external URL.
			'is_callable'        => '', // If set, this callable will be be checked for availability to determine if a plugin is active.
		),
		array(
			'name'               => 'Classic Editor Plugin',
			'slug'               => 'classic-editor-plugin',
			'source'             => get_template_directory() . '/includes/plugins/classic-editor.1.6.zip',
			'required'           => true, 
			'version'            => '1.6', 


			'force_activation'   => true, // If true, plugin is activated upon theme activation and cannot be deactivated until theme switch.
			'force_deactivation' => false, // If true, plugin is deactivated upon theme switch, useful for theme-specific plugins.
			'external_url'       => '', // If set, overrides default API URL and points to an external URL.
			'is_callable'        => '', // If set, this callable will be be checked for availability to determine if a plugin is active.
		),

	);




	$config = array(
		'id'           => 'Theme101',                 // Unique ID for hashing notices for multiple instances of TGMPA.
		'default_path' => '',                      // Default absolute path to bundled plugins.
		'menu'         => 'tgmpa-install-plugins', // Menu slug.
		'parent_slug'  => 'themes.php',            // Parent menu slug.
		'capability'   => 'edit_theme_options',    // Capability needed to view plugin install page, should be a capability associated with the parent menu used.
		'has_notices'  => true,                    // Show admin notices or not.
		'dismissable'  => false,                    // If false, a user cannot dismiss the nag message.
		'dismiss_msg'  => '',                      // If 'dismissable' is false, this message will be output at top of nag.
		'is_automatic' => true,                   // Automatically activate plugins after installation or not.
		'message'      => 'Theme Will Not Function Properly Without The Required Plugins. Install Immediately!!!',                      // Message to output right before the plugins table.

		
	);

	tgmpa( $plugins, $config );
}
