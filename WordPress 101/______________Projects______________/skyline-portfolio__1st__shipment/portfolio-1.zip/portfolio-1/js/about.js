gsap.registerPlugin(ScrollTrigger)



function init() {

    gsap.to('.textOne', {
        x: -150, scrollTrigger: {
            trigger: '.row1',
            start: 'top top',
            end: 'bottom center-=20%',
            scrub: true,
            // markers: {
            //     indent: 100,
            //     fontWeight: "bold"
            // }
        }
    })
    gsap.to('.textTwo', {
        x: 200, scrollTrigger: {
            trigger: '.row1',
            start: 'top top',
            end: 'bottom center-=20%',
            scrub: true,
            // markers: {
            //     indent: 100,
            //     fontWeight: "bold"
            // }
        }
    })
    gsap.to('.rocket', {
        y: -500, scrollTrigger: {
            trigger: '.row1',
            start: 'top top',
            end: 'bottom center-=20%',
            scrub: true,
        }
    })
    gsap.to('.smoke', {
        autoAlpha: 0, scrollTrigger: {
            trigger: '.row1',
            start: 'top top',
            end: 'bottom center-=20%',
            scrub: true,
        }
    })



}



window.addEventListener('load', function () {
    init();
});
