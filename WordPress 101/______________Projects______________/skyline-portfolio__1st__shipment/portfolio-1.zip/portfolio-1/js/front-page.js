gsap.registerPlugin(ScrollTrigger);

gsap.to(".panel:not(:last-child)", {
    yPercent: -100,
    ease: "slow",
    stagger: 0.5,
    scrollTrigger: {
        trigger: "#container",
        start: "top top",
        end: "+=300%",
        scrub: 1,
        pin: true
    }
});

gsap.set(".panel", { zIndex: (i, target, targets) => targets.length - i });

const navLinks = gsap.utils.toArray(".section_nav a");
navLinks.forEach((link, i) => {
    link.addEventListener("click", e => {
        e.preventDefault();
        gsap.to(window, { scrollTo: i * window.innerHeight });
    });
});

const panels = gsap.utils.toArray(".panel");
panels.forEach((panel, i) => {
    ScrollTrigger.create({
        start: 0,
        end: (i + 1) * innerHeight - innerHeight / 2,
        markers: false,
        onLeave: () => {
            if (navLinks[i + 1]) {
                gsap.to(navLinks[i + 1], { scale: 1.3, color: "#056ef7" });
                gsap.to(navLinks[i], { scale: 1, color: "#0b052f" });
            }
        },
        onEnterBack: () => {
            gsap.to(navLinks[i], { scale: 1.3, color: "#056ef7" });
            if (navLinks[i + 1]) {
                gsap.to(navLinks[i + 1], { scale: 1, color: "#0b052f" });
            }
        },
    })
});


// scroll down arrow animation
gsap.to(".arrow", { y: 12, ease: "power1.inOut", repeat: -1, yoyo: true });





// ===========================================



gsap.to(".rocket1", {
    yPercent: -170,
    ease: "slow",
    stagger: 0.5,
    scrollTrigger: {
        trigger: "#blue",
        start: "top top",
        end: "bottom bottom",
        scrub: 1,
        // markers: {
        //     indent: 100,
        //     fontWeight: "bold"
        // }
    }
});


const contact = document.querySelector(".contact");
contact.addEventListener("click", e => {
    e.preventDefault();
    gsap.to(window, { scrollTo: 5 * window.innerHeight });
});
