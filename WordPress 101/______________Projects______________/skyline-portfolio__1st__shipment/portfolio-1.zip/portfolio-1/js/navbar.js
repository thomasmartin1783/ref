

const hamburger = document.querySelector('.hamburger')
const navLinks1 = document.querySelector('.nav-links1')
const navLink1 = document.querySelector('.page_item')






let i = 0;
hamburger.addEventListener('click', () => {
    hamburger.classList.toggle('is-active')
    navLinks1.classList.toggle('active')
    i++;

    if (window.innerWidth < 700) {

        if (i % 2 != 0) {

            gsap.fromTo('.page_item', {
                scale: 0,
                opacity: 0,

            }, {
                scale: 1,
                opacity: 1,
            });
        }
    }



})
