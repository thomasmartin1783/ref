<?php 

/* Template Name: Page */ 

get_header();
wp_enqueue_style( 'page-page', get_template_directory_uri() . '/css/page-page.css');

?>

<?php if ( have_posts() ) : while ( have_posts() ) : the_post(); ?>


    <div class="page-container">

        <div class="page-title-img" style="background: no-repeat center/130% url(<?php the_field('page_title_image')?>);">
        </div>

        <div class="page-wrapper">
            <div class="page-inner">
                <h1 class="page-title"><?php the_title();?></h1>

                <p class="page-date"><?php the_time('F, j, Y'); ?></p>

                <img class="page-content-image" src="<?php the_field('page_content_image'); ?>" alt="">
    
                <p class="page-content"><?php the_content();?></p>
            </div>

            <aside class="page-sidebar">
                <?php dynamic_sidebar( 'sidebar_1' ); ?>
            </aside>

        </div>
        

        

        <footer class="ending">
            
            <?php if (get_theme_mod('theme_logo')) : ?>
                    
                <a class="logo" href='<?php echo esc_url( home_url( '/' )); ?>' title='<?php echo esc_attr( get_bloginfo( 'name' , 'display' ) ); ?>' rel='home'>
                    <img class="logo-image" src='<?php echo esc_url( get_theme_mod( 'theme_logo' ) ); ?>' alt='<?php echo esc_attr( get_bloginfo( 'name' , 'display' ) ); ?>' >
                </a>
            
            <?php else: ?>
                <a class="logo" href='<?php echo esc_url( home_url('/')); ?>' title='<?php echo esc_attr( get_bloginfo( 'name' , 'display' ) ); ?>' rel='home'>
                    <span class="logo-text">
                    <i class="fab fa-atlassian"></i> 

                    <?php echo esc_attr( get_theme_mod( 'text_logo' ) ); ?>
                    </span>   
                </a>
            <?php endif; ?>
        
        
            <?php dynamic_sidebar( 'footer_1' ); ?>


            <?php wp_nav_menu( array(
                'menu_class' => 'footer-nav-links',
                'container' => 'ul',
                
            )); ?>
        </footer>
        <div class="copy-right">
            © nibir@ether404.com  2020
        </div>



    </div>









<?php endwhile; else : ?>
    <p><?php esc_html_e( 'Sorry, no posts matched your criteria.' ); ?></p>
<?php endif; ?>




<?php get_footer();?>