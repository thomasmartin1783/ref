<?php 


get_header();
wp_enqueue_style( 'single-page', get_template_directory_uri() . '/css/single-page.css');

?>

<?php if ( have_posts() ) : while ( have_posts() ) : the_post(); ?>



    <div class="page-container">

        <div class="page-title-img" style="background: no-repeat center/130% url(<?php echo get_template_directory_uri().'/assets/mountain.jpg'?>);">
        </div>

        <div class="page-wrapper">
            <div class="page-inner">
                <h1 class="page-title">
                    <a href="<?php the_permalink(); ?>">
                    <?php the_title();?>
                    </a>
                </h1>

                <p class="page-date"><?php the_time('F, j, Y'); ?></p>

                <img class="page-content-image" src="<?php the_field('post_image');?>" alt="">


                <p class="single-post-author"><?php the_author(); ?></p>
                <p><?php the_category(); ?></p>


                <p class="page-content"><?php the_content();?></p>

                <div class="post-comments">
                    <?php comments_template(); ?> 
                </div>
                
            </div>

            <aside class="page-sidebar">
                <?php dynamic_sidebar( 'sidebar_2' ); ?>
            </aside>
        </div>






        <footer class="ending">
            
            <?php if (get_theme_mod('theme_logo')) : ?>
                    
                <a class="logo" href='<?php echo esc_url( home_url( '/' )); ?>' title='<?php echo esc_attr( get_bloginfo( 'name' , 'display' ) ); ?>' rel='home'>
                    <img class="logo-image" src='<?php echo esc_url( get_theme_mod( 'theme_logo' ) ); ?>' alt='<?php echo esc_attr( get_bloginfo( 'name' , 'display' ) ); ?>' >
                </a>
            
            <?php else: ?>
                <a class="logo" href='<?php echo esc_url( home_url('/')); ?>' title='<?php echo esc_attr( get_bloginfo( 'name' , 'display' ) ); ?>' rel='home'>
                    <span class="logo-text">
                    <i class="fab fa-atlassian"></i> 

                    <?php echo esc_attr( get_theme_mod( 'text_logo' ) ); ?>
                    </span>   
                </a>
            <?php endif; ?>
        
        
            <?php dynamic_sidebar( 'footer_1' ); ?>


            <?php wp_nav_menu( array(
                'menu_class' => 'footer-nav-links',
                'container' => 'ul',
                
            )); ?>
        </footer>
        <div class="copy-right">
            © nibir@ether404.com  2020
        </div>

    </div>






<?php endwhile; else : ?>
    <p><?php esc_html_e( 'Sorry, no posts matched your criteria.' ); ?></p>
<?php endif; ?>


<style>
    .post-categories {
        padding: .2rem 0;
        margin-bottom: 1rem;
        list-style: none;
        color: #4488ff;
        border-bottom: 3px solid #0e0739;
        display: inline-block;
    }
    
    /* .widget_archive li a, .widget_categories li a, .widget_meta li a, .widget_nav_menu li a, .widget_pages li a {
        color: #f0f8ff;
        text-decoration: none;
    }
    .widget_archive li, .widget_categories li, .widget_meta li, .widget_nav_menu li, .widget_pages {
        color: #888;
    } */
</style>





<?php get_footer();?>