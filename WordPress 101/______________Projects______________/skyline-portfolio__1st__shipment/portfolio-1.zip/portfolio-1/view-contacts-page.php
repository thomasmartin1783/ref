<?php 

/* Template Name: View Contacts Page */ 

get_header();
wp_enqueue_style( 'view-contacts-page', get_template_directory_uri() . '/css/view-contacts-page.css');

?>

<?php if ( have_posts() ) : while ( have_posts() ) : the_post(); ?>



<?php 
    global $wpdb;
	$result = $wpdb -> get_results("Select * from {$wpdb->base_prefix}contacts");
?>


    <div class="view-contacts-container">


        <div class="view-contacts-inner">

            <?php if(current_user_can('administrator')) { ?>

            <?php
    
            forEach ($result as $contact) { ?>
    
                <p class="view-contacts-contact">
                    <?php echo $contact->id?>
                  
                    <p class="view-contacts-contact-name">
                        <?php echo $contact->name; ?></p>
                    
                   <p class="view-contacts-contact-email">
                        <?php echo $contact->email; ?></p>
                    
                   <p>
                        <?php echo $contact->subject; ?></p>
                    
                   <p>
                        <?php echo $contact->details; ?></p> 
                   
               
                </p>
    
            <?php } ?>
            <?php } else { ?>

                <div class="view-contacts-not-allowed">
                    <h1>You are not allowed to view this page !!!</h1>
                    <a href="<?php echo get_home_url(); ?>">Please Go Back To Home...</a>
                </div>

                <?php  }  ?>

        </div>

        


    </div>        



<?php endwhile; else : ?>
    <p><?php esc_html_e( 'Sorry, no posts matched your criteria.' ); ?></p>
<?php endif; ?>





    
    <footer class="ending">
        
        <?php if (get_theme_mod('theme_logo')) : ?>
                
            <a class="logo" href='<?php echo esc_url( home_url( '/' )); ?>' title='<?php echo esc_attr( get_bloginfo( 'name' , 'display' ) ); ?>' rel='home'>
                <img class="logo-image" src='<?php echo esc_url( get_theme_mod( 'theme_logo' ) ); ?>' alt='<?php echo esc_attr( get_bloginfo( 'name' , 'display' ) ); ?>' >
            </a>
        
        <?php else: ?>
            <a class="logo" href='<?php echo esc_url( home_url('/')); ?>' title='<?php echo esc_attr( get_bloginfo( 'name' , 'display' ) ); ?>' rel='home'>
                <span class="logo-text">
                <i class="fab fa-atlassian"></i> 

                <?php echo esc_attr( get_theme_mod( 'text_logo' ) ); ?>
                </span>   
            </a>
        <?php endif; ?>
    
    
        <?php dynamic_sidebar( 'footer_1' ); ?>


        <?php wp_nav_menu( array(
            'menu_class' => 'footer-nav-links',
            'container' => 'ul',
            
        )); ?>
    </footer>
    <div class="copy-right">
        © nibir@ether404.com  2020
    </div>






<?php get_footer();?>